﻿document.addEventListener('DOMContentLoaded', function () {
    const registerButton = document.getElementById('register-button');
    const loadingOverlay = document.getElementById('loading-overlay');

    registerButton.addEventListener('click', function () {
        loadingOverlay.classList.remove('d-none');
        setTimeout(function () {
            
            loadingOverlay.classList.add('d-none');

            window.location.href = '/Registration/Confirmation';

        }, 3000); 
    });
});
