﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using RegisterApp.Models;
namespace RegisterApp.Controllers
{
    public class RegController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(UserDetails us)
        {
            if (ModelState.IsValid)
            {
                using (var context = new BankManagmentDB())
                {
                    bool isUnique = false;
                    int uniqueBankNumber = 0;

                    while (!isUnique)
                    {
                        uniqueBankNumber = new Random().Next(100000, 999999);
                        isUnique = !context.UserDetails.Any(item => item.BankNumber == uniqueBankNumber);
                    }
                    us.BankNumber = uniqueBankNumber; 

                    context.UserDetails.Add(us);
                    context.SaveChanges();
                }

                return View("Confirmation", us);
            }
            return View(us);
        }
    }
}
