﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using System;

namespace RegisterApp.Models
{
    public class UserDetails
    {
       
        [Required(ErrorMessage = "Enter id!")]
        [Display(Name = "Enter id : ")]
        public int Id { get; set; }
        [Required(ErrorMessage = "Enter first name!")]
        [Display(Name = "First Name: ")]
        public string Firstname { get; set; }

        [Required(ErrorMessage = "Enter last name!")]
        [Display(Name = "Last Name: ")]
        public string Lastname { get; set; }

        [Required(ErrorMessage = "Enter birth date!")]
        [Display(Name = "Birth Date: ")]
        [DataType(DataType.Date)]
        public DateTime Birthdate { get; set; }

        [Required(ErrorMessage = "Select gender!")]
        [Display(Name = "Gender: ")]
        public char Gender { get; set; }

        [Required(ErrorMessage = "Enter username!")]
        [Display(Name = "Username: ")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Enter password!")]
        [Display(Name = "Password: ")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Enter bank number!")]
        [Display(Name = "Bank Number: ")]
        public int BankNumber { get; set; }

        [Required(ErrorMessage = "Enter email address!")]
        [Display(Name = "Email: ")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Enter home address!")]
        [Display(Name = "Home Address: ")]
        public string Homeadress { get; set; }

        [Required(ErrorMessage = "Enter phone number!")]
        [Display(Name = "Phone Number: ")]
        [DataType(DataType.PhoneNumber)]
        public string Phonenumber { get; set; }



        

    }
}
