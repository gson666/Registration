﻿using Microsoft.EntityFrameworkCore;

namespace RegisterApp.Models
{
    public class BankManagmentDB : DbContext
    {
        public DbSet<UserDetails> UserDetails { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BankManagmentDB;Integrated Security=True");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserDetails>().ToTable("UserDetails");
        }
    }
}
